declare module 'react-image-magnify';
