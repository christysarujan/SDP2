interface CostCalc {
    orderId: string;
    productId: string;
   
  }
  
  export default CostCalc;