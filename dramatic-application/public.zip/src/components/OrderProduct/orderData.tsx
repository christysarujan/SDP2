interface OrderData {
    userId: any;
    productId: string;
    quantity: number;
    color : string;
    size : string;
  }
  
  export default OrderData;