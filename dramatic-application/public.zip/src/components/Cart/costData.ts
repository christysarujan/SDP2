interface CostData {
    cartId: string;
    productId: string;
    
  }
  
  export default CostData;