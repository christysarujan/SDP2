interface CartQuantityData {
    
    quantity: number;
    
  }
  
  export default CartQuantityData;