interface CartData {
    userId: string;
    productId: string;
    quantity: number;
    productPrice : string;
    color : string;
    size : string;
  }
  
  export default CartData;