import React from 'react'

const ProductList = () => {
  return (
    <div>
      <p>product list</p>
    </div>
  )
}

export default ProductList
