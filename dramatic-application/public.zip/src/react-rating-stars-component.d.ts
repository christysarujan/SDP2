declare module 'react-rating-stars-component';
